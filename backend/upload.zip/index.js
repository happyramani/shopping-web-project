const port = 4000;
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const cors = require('cors');

app.use(express.json())
app.use(cors());

mongoose.connect("mongodb://kinghapppy1:123Abcxy@ac-uyysoel-shard-00-00.ueo8uxk.mongodb.net:27017,ac-uyysoel-shard-00-01.ueo8uxk.mongodb.net:27017,ac-uyysoel-shard-00-02.ueo8uxk.mongodb.net:27017/inLancer?ssl=true&replicaSet=atlas-knjx2n-shard-0&authSource=admin&retryWrites=true&w=majority&appName=Cluster0");

app.get("/",(req, res) => {
    res.send("Express app is running");
})

const storage =multer.diskStorage({
    destination:"./upload/images",
    filename:(req,file,cb)=>{
        return cb(null, `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`)
    }
});

const upload = multer({storage: storage});

app.use('/images',express.static('upload/images'))

app.post('/upload', upload.single('product'), (req,res) => {
    res.json({
        success: 1,
        image_url: `http://192.168.0.57:${port}/images/${req.file.filename}`
    })
});

const Product = mongoose.model('Product', {
    id: {
        type: Number,
        required: true,
    },
    name: {
        type: String,
        required: true,
    },
    image: {
        type: String,
        required: true,
    },
    category: {
        type: String,
        required: true,
    },
    new_price: {
        type: Number,
        required: true,
    },
    old_price: {
        type: Number,
        required: true,
    },
    date: {
        type: Date,
        default: Date.now,
    },
    available: {
        type: Boolean,
        default: true,
    },
});

const User = mongoose.model('User',{
    name:{
        type: String,
    },
    email:{
        type: String,
        unique: true,
    },
    password:{
        type: String,
    },
    cartData:{
        type: Object,
    },
    date:{
        type: Date,
        default: Date.now,
    },
});

app.post('/signup', async(req, res, ) => {
    let check = await User.findOne({email:req.body.email})
    if(check){
        return res.status(400).json({
            success: false,
            error: "Existing user found with same email"
        })
    }
    let cart ={};
    for (let i = 0; i < 300; i++) {
        cart[i] =0;

    }
    const user = new User({
        name:req.body.name,
        email:req.body.email,
        password:req.body.password,
        cartData:req.body.cart
    })

    await user.save()
    const data = {
        user:{
            id:user.id,
        },
    };
    const token = jwt.sign(data, "secret_ecom");
    res.json({success:true, token})
})

app.post('/login', async (req, res) => {
    let user = await User.findOne({email: req.body.email});
    if(user){
        const passMatch = req.body.password === user.password;
        if(passMatch) {
            const data = {
                user:{
                    id:user.id,
                }
            }
            const token = jwt.sign(data,"secret_ecom");
            res.json({success:true, token})
        }
        else{
            res.json({success:false, error:"Wrong Password"})
        }
    }
    else{
       res.json({success:false, error:"Wrong Email Address"})
    }
})


// #region add product
app.post('/addproduct', async (req, res) => {
    let products = await Product.find({});
    let id;
    if (products.length > 0) {
        let last_product_array = products.slice(-1);
        let last_product = last_product_array[0];
        id = last_product.id + 1;
    } else {
        id = 1;
    }

    const product = new Product({
        id: id,
        name: req.body.name,
        image: req.body.image,
        category: req.body.category,
        new_price: req.body.new_price,
        old_price: req.body.old_price,
    });

    console.log(product);
    await product.save();
    console.log("Save");
    res.json({
        success: true,
        name: req.body.name,
    });
});

//#endregion

// #region delete product
app.post('/removeproduct', async (req, res) => {
    const { id } = req.body;
    await Product.findOneAndDelete({ id: id });
    console.log("Removed");
    res.json({
        success: true,
        name: req.body.name
    });
});
//#endregion

// #region select_all products
app.get("/allproducts",async(req,res)=>{
    let products =await Product.find({});
    console.log("All Products Fatched");
    res.send(products);
})
//#endregion

app.listen(port,"192.168.0.57",(error)=>{
    if(!error){
        console.log("Server listening on port " +port);
    }
    else{
        console.log("Error: " + error);
    }
})